package com.tj.blackjack;

/**
 * 
 * @author Tia Jackson
 *
 */
public class Player extends BlackjackPerson {

	// Create a Player
	Player(boolean isDealer) {
		super(isDealer);
	}
}
